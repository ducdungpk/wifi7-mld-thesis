// SPDX-License-Identifier: GPL-2.0-only
// Demo 2: STA sweep, SLO versus native MLD. ns-3.46 / 3.46.1.
// Permanent ARP entries are installed before data traffic; existing CSV schema.
// Throughput: FlowMonitor.rxBytes at IP layer; measurement duration is 9 s.
// Traffic starts after every STA has completed association and link mapping.
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/spectrum-module.h"
#include "ns3/wifi-module.h"
#include "ns3/udp-header.h"
#include "ns3/net-device-queue-interface.h"
#include <optional>
#include <tuple>

#include <array>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace ns3;

namespace
{
constexpr uint32_t PAYLOAD = 1200;
constexpr double ACTIVE_TIME = 9.0;
constexpr double SETUP_DEADLINE = 10.0;
double APP_START = 1.0;
double SIM_STOP = 10.0;
constexpr double RADIUS = 5.0;
constexpr std::array<uint16_t, 2> PORTS = {5000, 6000};

std::string mode = "mlo", caseId = "manual", output = ".";
uint32_t nSta = 1, seed = 1;
uint64_t rngRun = 1, sendErrors = 0;
double offeredLoad = 5.0;
uint8_t nLinks = 2;
bool mappingReady = false;
std::vector<Ptr<WifiNetDevice>> devices;
std::vector<std::array<Ptr<Socket>, 2>> sources;
Ipv4Address apIp;
std::vector<Ipv4Address> staIps;

struct Kpi
{
    uint64_t tx = 0, rx = 0, rxBytes = 0, jitterSamples = 0;
    long double delayNs = 0, jitterNs = 0;

    void AddFlow(const FlowMonitor::FlowStats& f)
    {
        tx += f.txPackets;
        rx += f.rxPackets;
        rxBytes += f.rxBytes;
        delayNs += f.delaySum.GetNanoSeconds();
        jitterNs += f.jitterSum.GetNanoSeconds();
        if (f.rxPackets > 1) jitterSamples += f.rxPackets - 1;
    }

    void Add(const Kpi& other)
    {
        tx += other.tx;
        rx += other.rx;
        rxBytes += other.rxBytes;
        jitterSamples += other.jitterSamples;
        delayNs += other.delayNs;
        jitterNs += other.jitterNs;
    }
};

std::string Number(long double value)
{
    std::ostringstream stream;
    stream << std::setprecision(12) << value;
    return stream.str();
}

long double Throughput(const Kpi& k)
{
    return 8.0L * k.rxBytes / (ACTIVE_TIME * 1e6L);
}

std::string Delay(const Kpi& k)
{
    return k.rx ? Number(k.delayNs / k.rx / 1e6L) : "NA";
}

std::string Jitter(const Kpi& k)
{
    return k.jitterSamples
        ? Number(k.jitterNs / k.jitterSamples / 1e6L) : "NA";
}

std::string Loss(const Kpi& k)
{
    return k.tx
        ? Number(100.0L * (static_cast<long double>(k.tx) - k.rx) / k.tx)
        : "NA";
}

void WriteKpi(std::ostream& stream, const Kpi& k)
{
    stream << k.tx << ',' << k.rx << ',' << k.rxBytes
           << ',' << Number(Throughput(k)) << ',' << Delay(k)
           << ',' << Jitter(k) << ',' << Loss(k);
}

std::string JoinReasons(const std::set<std::string>& reasons)
{
    if (reasons.empty()) return "OK";
    std::ostringstream stream;
    bool first = true;
    for (const auto& reason : reasons)
    {
        if (!first) stream << '|';
        stream << reason;
        first = false;
    }
    return stream.str();
}

// Use the existing IPv4-interface ARP caches. WifiNetDevice::GetAddress()
// gives the device/MLD address; do not use an individual PHY link address.
Ptr<ArpCache> GetCache(Ptr<WifiNetDevice> device)
{
    auto ipv4 = device->GetNode()->GetObject<Ipv4L3Protocol>();
    NS_ABORT_MSG_IF(!ipv4, "IPV4_STACK_MISSING");
    const int32_t index = ipv4->GetInterfaceForDevice(device);
    NS_ABORT_MSG_IF(index < 0, "IPV4_INTERFACE_MISSING");
    auto cache = ipv4->GetInterface(static_cast<uint32_t>(index))->GetArpCache();
    NS_ABORT_MSG_IF(!cache, "ARP_CACHE_MISSING");
    return cache;
}

void SetPermanent(Ptr<ArpCache> cache, Ipv4Address ip, Address mac)
{
    auto entry = cache->Lookup(ip);
    if (!entry) entry = cache->Add(ip);
    entry->SetMacAddress(mac);
    entry->MarkPermanent();
}

void InstallPermanentArp()
{
    auto apCache = GetCache(devices[0]);
    for (uint32_t i = 0; i < nSta; ++i)
    {
        SetPermanent(GetCache(devices[i + 1]), apIp, devices[0]->GetAddress());
        SetPermanent(apCache, staIps[i], devices[i + 1]->GetAddress());
    }
    std::cout << "ARP_SETUP=OK policy=STATIC peers=" << nSta << '\n';
}


struct RxProbe
{
    uint64_t sendCalls = 0, sendOk = 0, macIn = 0, macReject = 0;
    uint64_t enq = 0, deq = 0, before = 0, after = 0, expired = 0;
    uint64_t acked = 0, nacked = 0, dropped = 0, appRx = 0;
    double firstRx = -1;
    std::map<int, uint64_t> reasons;
};
std::vector<std::array<RxProbe, 2>> probe;
std::map<uint32_t, uint32_t> probeSource;
std::ofstream rxDiag, rxTimeline, rxReasons;
uint64_t unknownSource = 0;


// Read-only snapshots. Queue IDs come from actual enqueued QoS MPDUs.
std::vector<std::array<std::optional<WifiContainerQueueId>, 2>> observedQueue;
std::ofstream rxState;

std::string BaState(Ptr<WifiMac> mac, Mac48Address recipient, uint8_t tid)
{
    auto agreement = mac->GetQosTxop(AC_BE)->GetBaManager()
                         ->GetAgreementAsOriginator(recipient, tid);
    if (!agreement) return "ABSENT";
    const auto& a = agreement->get();
    if (a.IsPending()) return "PENDING";
    if (a.IsEstablished()) return "ESTABLISHED";
    if (a.IsNoReply()) return "NO_REPLY";
    if (a.IsReset()) return "RESET";
    if (a.IsRejected()) return "REJECTED";
    return "UNKNOWN";
}

void StateSnapshot(uint32_t sta, uint8_t plannedPhy)
{
    auto device = devices[sta + 1];
    auto mac = device->GetMac();
    auto queue = mac->GetQosTxop(AC_BE)->GetWifiMacQueue();
    auto ndqi = device->GetObject<NetDeviceQueueInterface>();
    const auto& id = observedQueue[sta][plannedPhy];
    const uint8_t tid = plannedPhy == 0 ? 0 : 3;
    for (uint8_t phy = 0; phy < nLinks; ++phy)
    {
        const auto link = mac->GetLinkForPhy(phy);
        std::string maskValue = "NA", reasons = "NO_QUEUE_OBSERVED";
        if (id && link)
        {
            auto mask = mac->GetMacQueueScheduler()->GetQueueLinkMask(AC_BE, *id, *link);
            reasons = "NO_MASK";
            if (mask)
            {
                maskValue = std::to_string(mask->to_ullong());
                reasons.clear();
                for (std::size_t bit = 0;
                     bit < static_cast<std::size_t>(WifiQueueBlockedReason::REASONS_COUNT); ++bit)
                {
                    if (!mask->test(bit)) continue;
                    if (!reasons.empty()) reasons += '|';
                    std::ostringstream text;
                    text << static_cast<WifiQueueBlockedReason>(bit);
                    reasons += text.str();
                }
                if (reasons.empty()) reasons = "UNBLOCKED";
            }
        }
        std::string stopped;
        if (ndqi)
            for (std::size_t k = 0; k < ndqi->GetNTxQueues(); ++k)
            {
                if (k) stopped += '|';
                stopped += std::to_string(k) + ':' +
                           (ndqi->GetTxQueue(k)->IsStopped() ? "STOPPED" : "RUNNING");
            }
        if (stopped.empty()) stopped = "NO_INTERFACE_QUEUE";
        const Mac48Address peer = id ? std::get<2>(*id) : devices[0]->GetMac()->GetAddress();
        const auto recipient = devices[0]->GetMac()->GetBaAgreementEstablishedAsRecipient(
            mac->GetAddress(), tid);
        rxState << caseId << ',' << sta << ',' << +plannedPhy << ',' << +tid << ','
                << Number((Simulator::Now() - Seconds(APP_START)).GetSeconds()) << ','
                << +phy << ',' << (link ? std::to_string(*link) : "NA") << ','
                << (id ? "1" : "0") << ',' << queue->GetNPackets() << ','
                << (id ? std::to_string(queue->GetNPackets(*id)) : "NA") << ','
                << maskValue << ',' << reasons << ',' << BaState(mac, peer, tid) << ','
                << (recipient ? "ESTABLISHED" : "NOT_ESTABLISHED") << ','
                << (recipient ? std::to_string(recipient->get().GetStartingSequence()) : "NA")
                << ',' << stopped << '\n';
    }
}


// Foundation-only instrumentation; never remove queue entries or draw extra RNG samples.
uint32_t checkWidth = 20;
bool checkFading = false;
double checkSpeed = 0;
std::vector<Ptr<PropagationLossModel>> checkLoss;
std::ofstream phyAudit, mechanismAudit, mobilityAudit;
std::vector<std::array<uint64_t, 2>> actualTx;
uint64_t phyMismatch = 0;

void BeginCheckMotion()
{
    if (checkSpeed <= 0) return;
    for (uint32_t i = 0; i < nSta; ++i)
    {
        const double angle = 2 * std::acos(-1.0) * i / nSta;
        auto m = devices[i + 1]->GetNode()->GetObject<ConstantVelocityMobilityModel>();
        NS_ABORT_MSG_IF(!m, "CHECK_MOBILITY_MODEL_MISSING");
        m->SetVelocity(Vector(-checkSpeed * std::sin(angle), checkSpeed * std::cos(angle), 0));
    }
}

void ObservePhy(uint32_t sta, uint8_t phy, WifiConstPsduMap map,
                WifiTxVector vector, double powerW)
{
    (void)powerW;
    for (const auto& item : map)
    {
        for (std::size_t k = 0; k < item.second->GetNMpdus(); ++k)
        {
            const auto& header = item.second->GetHeader(k);
            if (!header.IsQosData()) continue;
            const uint8_t tid = header.GetQosTid();
            const int expected = tid == 0 ? 0 : (tid == 3 ? 1 : -1);
            ++actualTx[sta][phy];
            const auto dataMode = vector.GetMode(item.first);
            const uint8_t mcs = dataMode.GetModulationClass() == WIFI_MOD_CLASS_EHT
                ? dataMode.GetMcsValue() : 255;
            const auto nss = vector.GetNss(item.first);
            const auto gi = vector.GetGuardInterval().GetNanoSeconds();
            const bool ok = expected == phy && mcs == 9 && nss == 1 && gi == 3200 &&
                            !vector.IsLdpc() && static_cast<double>(vector.GetChannelWidth()) == checkWidth;
            if (!ok) ++phyMismatch;
            // One row per first QoS MPDU on this PHY, plus every mismatch.
            if (actualTx[sta][phy] == 1 || !ok)
                phyAudit << caseId << ',' << sta << ',' << +phy << ',' << +tid << ','
                         << +mcs << ',' << +nss << ',' << gi << ',' << vector.IsLdpc()
                         << ',' << static_cast<double>(vector.GetChannelWidth()) << ',' << ok << '\n';
        }
    }
}

void ObserveMobility(uint32_t sta)
{
    const auto m = devices[sta + 1]->GetNode()->GetObject<MobilityModel>();
    const auto pos = m->GetPosition();
    const auto vel = m->GetVelocity();
    mobilityAudit << caseId << ',' << sta << ','
        << Number((Simulator::Now() - Seconds(APP_START)).GetSeconds()) << ','
        << Number(pos.x) << ',' << Number(pos.y) << ',' << Number(pos.z) << ','
        << Number(vel.x) << ',' << Number(vel.y) << ',' << Number(vel.z) << '\n';
}

int IpLink(Ptr<const Packet> packet)
{
    if (packet->GetSize() < 36) return -1;
    auto copy = packet->Copy();
    LlcSnapHeader llc;
    copy->RemoveHeader(llc);
    if (llc.GetType() != 0x0800) return -1;
    Ipv4Header ip;
    copy->RemoveHeader(ip);
    if (ip.GetProtocol() != 17 || ip.GetDestination() != apIp) return -1;
    UdpHeader udp;
    copy->PeekHeader(udp);
    if (udp.GetDestinationPort() == PORTS[0]) return 0;
    if (udp.GetDestinationPort() == PORTS[1]) return 1;
    return -1;
}

int MpduLink(Ptr<const WifiMpdu> mpdu)
{
    const auto& h = mpdu->GetHeader();
    if (!h.IsQosData()) return -1;
    const uint8_t tid = h.GetQosTid();
    if (tid == 0) return 0;
    if (tid == 3) return 1;
    return -1;
}

void MacIp(uint32_t sta, bool reject, Ptr<const Packet> p)
{
    const int l = IpLink(p);
    if (l < 0 || l >= nLinks) return;
    if (reject) ++probe[sta][l].macReject;
    else ++probe[sta][l].macIn;
}

void MpduEvent(uint32_t sta, uint8_t event, Ptr<const WifiMpdu> mpdu)
{
    const int l = MpduLink(mpdu);
    if (l < 0 || l >= nLinks) return;
    auto& d = probe[sta][l];
    switch (event)
    {
    case 0: ++d.enq; observedQueue[sta][l] = WifiMacQueueContainer::GetQueueId(mpdu); break;
    case 1: ++d.deq; break;
    case 2: ++d.before; break;
    case 3: ++d.after; break;
    case 4: ++d.expired; break;
    case 5: ++d.acked; break;
    case 6: ++d.nacked; break;
    }
}

void Dropped(uint32_t sta, WifiMacDropReason reason, Ptr<const WifiMpdu> mpdu)
{
    const int l = MpduLink(mpdu);
    if (l < 0 || l >= nLinks) return;
    auto& d = probe[sta][l];
    ++d.dropped;
    ++d.reasons[static_cast<int>(reason)];
}

bool PermanentAtSta(uint32_t sta)
{
    auto e = GetCache(devices[sta + 1])->Lookup(apIp);
    return e && e->IsPermanent() && e->GetMacAddress() == devices[0]->GetAddress();
}

bool PermanentAtAp(uint32_t sta)
{
    auto e = GetCache(devices[0])->Lookup(staIps[sta]);
    return e && e->IsPermanent() && e->GetMacAddress() == devices[sta + 1]->GetAddress();
}

void ProbeSnapshot()
{
    for (uint32_t i = 0; i < nSta; ++i)
    {
        auto mac = DynamicCast<StaWifiMac>(devices[i + 1]->GetMac());
        for (uint8_t l = 0; l < nLinks; ++l)
        {
            const auto& d = probe[i][l];
            StateSnapshot(i, l);
            if (l == 0) ObserveMobility(i);
            rxTimeline << caseId << ',' << i << ',' << +l << ','
                << Number((Simulator::Now() - Seconds(APP_START)).GetSeconds())
                << ',' << mac->IsAssociated() << ',' << mac->GetSetupLinkIds().size()
                << ',' << PermanentAtSta(i) << ',' << PermanentAtAp(i)
                << ',' << d.sendCalls << ',' << d.sendOk
                << ',' << d.macIn << ',' << d.macReject
                << ',' << d.enq << ',' << d.deq << ',' << d.before
                << ',' << d.after << ',' << d.expired
                << ',' << d.acked << ',' << d.nacked << ',' << d.dropped
                << ',' << d.appRx << '\n';
        }
    }
}

void ConnectProbes()
{
    probe.resize(nSta);
    observedQueue.resize(nSta);
    actualTx.resize(nSta);
    for (uint32_t i = 0; i < nSta; ++i)
    {
        auto mac = devices[i + 1]->GetMac();
        auto q = mac->GetQosTxop(AC_BE)->GetWifiMacQueue();
        bool ok = mac->TraceConnectWithoutContext("MacTx", MakeBoundCallback(&MacIp, i, false));
        ok &= mac->TraceConnectWithoutContext("MacTxDrop", MakeBoundCallback(&MacIp, i, true));
        const std::array<std::string, 5> names =
            {"Enqueue", "Dequeue", "DropBeforeEnqueue", "DropAfterDequeue", "Expired"};
        for (uint8_t e = 0; e < names.size(); ++e)
            ok &= q->TraceConnectWithoutContext(names[e], MakeBoundCallback(&MpduEvent, i, e));
        ok &= mac->TraceConnectWithoutContext("AckedMpdu", MakeBoundCallback(&MpduEvent, i, uint8_t{5}));
        ok &= mac->TraceConnectWithoutContext("NAckedMpdu", MakeBoundCallback(&MpduEvent, i, uint8_t{6}));
        ok &= mac->TraceConnectWithoutContext("DroppedMpdu", MakeBoundCallback(&Dropped, i));
        for (uint8_t p = 0; p < nLinks; ++p)
            ok &= devices[i + 1]->GetPhy(p)->TraceConnectWithoutContext(
                "PhyTxPsduBegin", MakeBoundCallback(&ObservePhy, i, p));
        NS_ABORT_MSG_IF(!ok, "RX_PROBE_TRACE_CONNECT_FAILED sta=" << i);
    }
}

void Receive(Ptr<Socket> socket)
{
    Address from;
    while (auto packet = socket->RecvFrom(from))
    {
        if (!InetSocketAddress::IsMatchingType(from)) { ++unknownSource; continue; }
        const auto ip = InetSocketAddress::ConvertFrom(from).GetIpv4();
        const auto found = probeSource.find(ip.Get());
        if (found == probeSource.end()) { ++unknownSource; continue; }
        Address local;
        socket->GetSockName(local);
        const auto port = InetSocketAddress::ConvertFrom(local).GetPort();
        const uint8_t l = port == PORTS[0] ? 0 : 1;
        auto& d = probe[found->second][l];
        ++d.appRx;
        if (d.firstRx < 0)
            d.firstRx = (Simulator::Now() - Seconds(APP_START)).GetSeconds();
    }
}

void Send(uint32_t sta, uint8_t link)
{
    if (Simulator::Now() >= Seconds(SIM_STOP)) return;
    auto packet = Create<Packet>(PAYLOAD);
    ++probe[sta][link].sendCalls;
    if (sources[sta][link]->Send(packet) != static_cast<int>(PAYLOAD))
        ++sendErrors;
    else
        ++probe[sta][link].sendOk;

    const double loadPerLink = offeredLoad / nLinks;
    const double interval = PAYLOAD * 8.0 / (loadPerLink * 1e6);
    Simulator::Schedule(Seconds(interval), &Send, sta, link);
}

void ConfigureMapping()
{
    uint32_t readyCount = 0;
    for (uint32_t i = 0; i < nSta; ++i)
    {
        auto mac = DynamicCast<StaWifiMac>(devices[i + 1]->GetMac());
        if (mac->IsAssociated() && mac->GetSetupLinkIds().size() == nLinks)
            ++readyCount;
    }

    if (readyCount != nSta)
    {
        if (Simulator::Now() < Seconds(SETUP_DEADLINE))
        {
            Simulator::Schedule(MilliSeconds(100), &ConfigureMapping);
            return;
        }
        std::cout << "MLD_SETUP=FAIL ready_sta=" << readyCount << '/' << nSta
                  << " setup_deadline_s=" << SETUP_DEADLINE << '\n';
        for (uint32_t i = 0; i < nSta; ++i)
        {
            auto mac = DynamicCast<StaWifiMac>(devices[i + 1]->GetMac());
            if (!mac->IsAssociated() || mac->GetSetupLinkIds().size() != nLinks)
                std::cout << "UNREADY_STA sta_id=" << i
                          << " associated=" << mac->IsAssociated()
                          << " setup_links=" << mac->GetSetupLinkIds().size() << '\n';
        }
        Simulator::Stop();
        return;
    }

    if (nLinks == 2)
    {
        for (uint32_t i = 0; i < nSta; ++i)
        {
            auto mac = DynamicCast<StaWifiMac>(devices[i + 1]->GetMac());
            for (uint8_t phy = 0; phy < 2; ++phy)
            {
                auto blockedLink = mac->GetLinkForPhy(1 - phy);
                if (!blockedLink)
                {
                    std::cout << "MLD_SETUP=FAIL mapping_sta=" << i
                              << " phy=" << +phy << '\n';
                    Simulator::Stop();
                    return;
                }
                mac->GetMacQueueScheduler()->BlockQueues(
                    WifiQueueBlockedReason::TID_NOT_MAPPED,
                    AC_BE, {WIFI_QOSDATA_QUEUE},
                    devices[0]->GetMac()->GetAddress(), mac->GetAddress(),
                    {static_cast<uint8_t>(phy == 0 ? 0 : 3)}, {*blockedLink});
            }
        }
    }

    InstallPermanentArp();
    mappingReady = true;
    APP_START = Simulator::Now().GetSeconds() + 0.1;
    if (APP_START < 1.0) APP_START = 1.0;
    SIM_STOP = APP_START + ACTIVE_TIME;
    const Time startDelay = Seconds(APP_START) - Simulator::Now();
    Simulator::Schedule(startDelay, &BeginCheckMotion);
    for (double offset : {0.0, 1.0, 3.0, 6.0, 8.9})
        Simulator::Schedule(startDelay + Seconds(offset), &ProbeSnapshot);
    for (uint32_t i = 0; i < nSta; ++i)
        for (uint8_t link = 0; link < nLinks; ++link)
            Simulator::ScheduleWithContext(
                devices[i + 1]->GetNode()->GetId(), startDelay, &Send, i, link);

    // Stop(Time) is relative to the current simulation time.
    Simulator::Stop(Seconds(SIM_STOP) - Simulator::Now());
    std::cout << "MLD_SETUP=OK links_per_sta=" << +nLinks
              << " ready_sta=" << readyCount
              << " app_start_s=" << APP_START << " sim_stop_s=" << SIM_STOP
              << " measure_s=" << ACTIVE_TIME << '\n';
}
} // namespace

int main(int argc, char* argv[])
{
    CommandLine command(__FILE__);
    command.AddValue("mode", "slo5 or mlo", mode);
    command.AddValue("width", "Diagnostic channel width 20/40/80", checkWidth);
    command.AddValue("fading", "Diagnostic Nakagami on every PHY channel", checkFading);
    command.AddValue("speed", "Diagnostic tangential speed in m/s", checkSpeed);
    command.AddValue("nSta", "Number of physical STAs", nSta);
    command.AddValue("offeredLoad", "Total offered UDP Mbps per STA", offeredLoad);
    command.AddValue("seed", "RNG seed", seed);
    command.AddValue("run", "RNG run", rngRun);
    command.AddValue("caseId", "CSV case identifier", caseId);
    command.AddValue("out", "Existing output directory", output);
    command.Parse(argc, argv);
    std::cout << std::unitbuf;

    if ((mode != "slo5" && mode != "slo6" && mode != "mlo") || nSta < 1 || nSta > 50 ||
        !std::isfinite(offeredLoad) || offeredLoad <= 0 || offeredLoad > 500 ||
        !seed || !rngRun || (checkWidth != 20 && checkWidth != 40 && checkWidth != 80) ||
        (mode == "slo6" && checkWidth != 20) || (mode == "mlo" && checkWidth != 20) ||
        !std::isfinite(checkSpeed) || checkSpeed < 0 || checkSpeed > 1 || caseId.empty() ||
        caseId.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")
            != std::string::npos)
    {
        std::cerr << "INVALID_ARGUMENTS\n";
        return 2;
    }

    std::ofstream summary(output + "/summary.csv");
    std::ofstream perSta(output + "/per_sta.csv");
    std::ofstream perLink(output + "/per_link.csv");
    rxDiag.open(output + "/rx_diagnostic.csv");
    rxTimeline.open(output + "/rx_timeline.csv");
    rxReasons.open(output + "/mac_drop_reasons.csv");
    rxState.open(output + "/rx_state.csv");
    phyAudit.open(output + "/phy_audit.csv");
    mechanismAudit.open(output + "/mechanism.csv");
    mobilityAudit.open(output + "/mobility.csv");
    phyAudit << "case_id,sta_id,actual_phy,tid,mcs,nss,gi_ns,ldpc,width_mhz,valid\n";
    mechanismAudit << "case_id,phy_id,band_ghz,width_mhz,fading,loss_chain,stream_start,mobility_speed_mps\n";
    mobilityAudit << "case_id,sta_id,elapsed_s,x_m,y_m,z_m,vx_mps,vy_mps,vz_mps\n";
    rxState << "case_id,sta_id,planned_phy,tid,elapsed_s,observed_phy,mac_link_id,queue_observed,ac_be_total_mpdu,tid_queue_mpdu,blocked_mask,blocked_reasons,originator_ba_state,ap_recipient_ba_state,ap_rx_window_start,device_tx_queue_states\n";
    if (!summary || !perSta || !perLink || !rxDiag || !rxTimeline || !rxReasons || !rxState || !phyAudit || !mechanismAudit || !mobilityAudit)
    {
        std::cerr << "OUTPUT_OPEN_FAILED\n";
        return 2;
    }
    summary << std::setprecision(12);
    perSta << std::setprecision(12);
    perLink << std::setprecision(12);
    rxTimeline << "case_id,sta_id,phy_id,elapsed_s,associated,setup_links,arp_sta_permanent,arp_ap_permanent,app_send_calls,app_send_ok,mac_ip_submitted,mac_ip_rejected,queue_enq_mpdu_events,queue_deq_mpdu_events,queue_before_drop_mpdu_events,queue_after_drop_mpdu_events,queue_expired_mpdu_events,acked_mpdu_events,nacked_mpdu_events,dropped_mpdu_events,app_rx_packets\n";
    nLinks = mode == "mlo" ? 2 : 1;

    RngSeedManager::SetSeed(seed);
    RngSeedManager::SetRun(rngRun);
    Config::SetDefault("ns3::HtConfiguration::LdpcSupported", BooleanValue(false));

    NodeContainer ap, stas;
    ap.Create(1);
    stas.Create(nSta);
    auto positions = CreateObject<ListPositionAllocator>();
    positions->Add(Vector(0, 0, 1.5));
    for (uint32_t i = 0; i < nSta; ++i)
    {
        const double angle = 2.0 * std::acos(-1.0) * i / nSta;
        positions->Add(Vector(RADIUS * std::cos(angle), RADIUS * std::sin(angle), 1.5));
    }
    MobilityHelper mobility;
    mobility.SetPositionAllocator(positions);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(ap);
    if (checkSpeed > 0) mobility.SetMobilityModel("ns3::ConstantVelocityMobilityModel");
    mobility.Install(stas);

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211be);
    wifi.ConfigEhtOptions("EmlsrActivated", BooleanValue(false));
    SpectrumWifiPhyHelper phy(nLinks);
    for (uint8_t link = 0; link < nLinks; ++link)
    {
        wifi.SetRemoteStationManager(
            link, "ns3::ConstantRateWifiManager",
            "DataMode", StringValue("EhtMcs9"),
            "ControlMode", StringValue("EhtMcs0"));
        phy.Set(link, "TxPowerStart", DoubleValue(16.0206));
        phy.Set(link, "TxPowerEnd", DoubleValue(16.0206));
        phy.Set(link, "RxNoiseFigure", DoubleValue(7.0));
        phy.Set(link, "MaxSupportedTxSpatialStreams", UintegerValue(1));
        phy.Set(link, "MaxSupportedRxSpatialStreams", UintegerValue(1));
        auto channel = CreateObject<MultiModelSpectrumChannel>();
        auto loss = CreateObject<LogDistancePropagationLossModel>();
        loss->SetAttribute("Exponent", DoubleValue(3.0));
        loss->SetAttribute("ReferenceDistance", DoubleValue(1.0));
        loss->SetAttribute("ReferenceLoss", DoubleValue(46.6777));
        if (checkFading)
        {
            auto fading = CreateObject<NakagamiPropagationLossModel>();
            fading->SetAttribute("m0", DoubleValue(1.0));
            fading->SetAttribute("m1", DoubleValue(1.0));
            fading->SetAttribute("m2", DoubleValue(1.0));
            loss->SetNext(fading);
        }
        checkLoss.push_back(loss);
        channel->AddPropagationLossModel(loss);
        channel->SetPropagationDelayModel(CreateObject<ConstantSpeedPropagationDelayModel>());
        const bool is6 = mode == "slo6" || link == 1;
        phy.AddChannel(channel, is6 ? WIFI_SPECTRUM_6_GHZ : WIFI_SPECTRUM_5_GHZ);
        const uint32_t channelNumber = is6 ? 1 : (checkWidth == 20 ? 36 : (checkWidth == 40 ? 38 : 42));
        const std::string setting = "{" + std::to_string(channelNumber) + "," +
            std::to_string(checkWidth) + "," + (is6 ? "BAND_6GHZ" : "BAND_5GHZ") + ",0}";
        phy.Set(link, "ChannelSettings", StringValue(setting));
    }

    WifiMacHelper mac;
    Ssid ssid("demo2-native-mld");
    mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));
    auto apDevices = wifi.Install(phy, mac, ap);
    mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid),
                "ActiveProbing", BooleanValue(false),
                "AssocType", EnumValue(WifiAssocType::ML_SETUP));
    auto staDevices = wifi.Install(phy, mac, stas);
    devices.push_back(DynamicCast<WifiNetDevice>(apDevices.Get(0)));
    for (uint32_t i = 0; i < nSta; ++i)
        devices.push_back(DynamicCast<WifiNetDevice>(staDevices.Get(i)));

    bool topologyOk = true;
    for (const auto& device : devices)
    {
        topologyOk &= device->GetNPhys() == nLinks;
        device->GetHeConfiguration()->SetAttribute("GuardInterval", TimeValue(NanoSeconds(3200)));
        for (uint8_t link = 0; link < nLinks; ++link)
            device->GetPhy(link)->SetErrorRateModel(CreateObject<TableBasedErrorRateModel>());
    }

    InternetStackHelper internet;
    internet.Install(ap);
    internet.Install(stas);
    Ipv4AddressHelper addresses;
    addresses.SetBase("10.81.0.0", "255.255.255.0");
    auto apInterfaces = addresses.Assign(apDevices);
    auto staInterfaces = addresses.Assign(staDevices);
    const auto apAddress = apInterfaces.GetAddress(0);
    apIp = apAddress;
    staIps.resize(nSta);
    std::map<uint32_t, uint32_t> sourceIndex;
    for (uint32_t i = 0; i < nSta; ++i)
    {
        staIps[i] = staInterfaces.GetAddress(i);
        sourceIndex[staIps[i].Get()] = i;
    }

    std::array<Ptr<Socket>, 2> sinks;
    for (uint8_t link = 0; link < nLinks; ++link)
    {
        sinks[link] = Socket::CreateSocket(ap.Get(0), UdpSocketFactory::GetTypeId());
        NS_ABORT_MSG_IF(sinks[link]->Bind(
            InetSocketAddress(Ipv4Address::GetAny(), PORTS[link])), "UDP sink bind failed");
        sinks[link]->SetRecvCallback(MakeCallback(&Receive));
    }
    sources.resize(nSta);
    for (uint32_t i = 0; i < nSta; ++i)
    {
        for (uint8_t link = 0; link < nLinks; ++link)
        {
            auto socket = Socket::CreateSocket(stas.Get(i), UdpSocketFactory::GetTypeId());
            socket->SetIpTos(link == 0 ? 0 : 0x60);
            socket->SetPriority(link == 0 ? 0 : 3);
            NS_ABORT_MSG_IF(socket->Connect(InetSocketAddress(apAddress, PORTS[link])),
                            "UDP source connect failed");
            sources[i][link] = socket;
        }
    }
    probeSource = sourceIndex;
    ConnectProbes();
    wifi.AssignStreams(apDevices, 100);
    wifi.AssignStreams(staDevices, 10000);
    for (uint8_t p = 0; p < nLinks; ++p)
    {
        const bool hasFading = !!DynamicCast<NakagamiPropagationLossModel>(checkLoss[p]->GetNext());
        NS_ABORT_MSG_IF(hasFading != checkFading, "CHECK_FADING_CHAIN_MISMATCH");
        if (hasFading) checkLoss[p]->AssignStreams(20000 + 100 * p);
        mechanismAudit << caseId << ',' << +p << ','
            << (devices[0]->GetPhy(p)->GetPhyBand() == WIFI_PHY_BAND_6GHZ ? 6 : 5)
            << ',' << static_cast<double>(devices[0]->GetPhy(p)->GetChannelWidth()) << ',' << hasFading << ','
            << (hasFading ? "LogDistance+Nakagami_m1" : "LogDistance") << ','
            << (hasFading ? std::to_string(20000 + 100 * p) : "NA") << ',' << checkSpeed << '\n';
    }
    FlowMonitorHelper flowHelper;
    auto monitor = flowHelper.InstallAll();
    Simulator::Schedule(Seconds(0.9), &ConfigureMapping);
    std::cout << "CONFIG case_id=" << caseId << " mode=" << mode << " n_sta=" << nSta
              << " offered_per_sta_mbps=" << offeredLoad
              << " offered_total_mbps=" << nSta * offeredLoad << " rng_run=" << rngRun << '\n';
    Simulator::Run();
    if (mappingReady) ProbeSnapshot();
    monitor->CheckForLostPackets();

    auto classifier = DynamicCast<Ipv4FlowClassifier>(flowHelper.GetClassifier());
    std::vector<std::array<Kpi, 2>> stationLink(nSta);
    bool countersOk = true;
    for (const auto& item : monitor->GetFlowStats())
    {
        const auto tuple = classifier->FindFlow(item.first);
        if (tuple.protocol != 17 || tuple.destinationAddress != apAddress ||
            (tuple.destinationPort != PORTS[0] && tuple.destinationPort != PORTS[1])) continue;
        auto station = sourceIndex.find(tuple.sourceAddress.Get());
        if (station == sourceIndex.end()) { countersOk = false; continue; }
        const uint8_t link = tuple.destinationPort == PORTS[0] ? 0 : 1;
        if (link >= nLinks) { countersOk = false; continue; }
        stationLink[station->second][link].AddFlow(item.second);
    }

    std::set<std::string> reasons;
    if (!topologyOk) reasons.insert("DEVICE_STRUCTURE");
    if (!mappingReady) reasons.insert("ASSOCIATION_MAPPING");
    if (sendErrors) reasons.insert("SOCKET_SEND_ERROR");
    if (!countersOk) reasons.insert("FLOW_CLASSIFICATION");
    if (unknownSource) reasons.insert("UNKNOWN_APP_SOURCE");
    if (phyMismatch) reasons.insert("ACTUAL_PHY_CONFIGURATION_OR_MAPPING");
    for (uint32_t i = 0; i < nSta; ++i)
        if (!PermanentAtSta(i) || !PermanentAtAp(i)) reasons.insert("ARP_PEER_MAPPING");
    std::vector<Kpi> stationTotal(nSta);
    std::array<Kpi, 2> linkTotal;
    Kpi total;
    long double sumThroughput = 0, sumThroughputSquared = 0;
    for (uint32_t i = 0; i < nSta; ++i)
    {
        for (uint8_t link = 0; link < nLinks; ++link)
        {
            const auto& k = stationLink[i][link];
            if (k.rx > k.tx) reasons.insert("INVALID_COUNTERS");
            if (probe[i][link].appRx != k.rx) reasons.insert("APP_FLOW_RX_MISMATCH");
            if (probe[i][link].sendOk != k.tx) reasons.insert("APP_FLOW_TX_MISMATCH");
            stationTotal[i].Add(k);
            linkTotal[link].Add(k);
        }
        total.Add(stationTotal[i]);
        const auto throughput = Throughput(stationTotal[i]);
        sumThroughput += throughput;
        sumThroughputSquared += throughput * throughput;
        auto staMac = DynamicCast<StaWifiMac>(devices[i + 1]->GetMac());
        if (staMac->GetSetupLinkIds().size() != nLinks) reasons.insert("FINAL_LINK_SETUP");
    }
    const std::string jain = sumThroughputSquared > 0
        ? Number(sumThroughput * sumThroughput / (nSta * sumThroughputSquared)) : "NA";
    rxDiag << "case_id,demo,mode,sta_id,phy_id,tid,planned_load_mbps,setup_links,arp_sta_permanent,arp_ap_permanent,app_send_calls,app_send_ok,mac_ip_submitted,mac_ip_rejected,queue_enq_mpdu_events,queue_deq_mpdu_events,queue_before_drop_mpdu_events,queue_after_drop_mpdu_events,queue_expired_mpdu_events,acked_mpdu_events,nacked_mpdu_events,dropped_mpdu_events,flow_tx_packets,flow_rx_packets,app_rx_packets,first_rx_elapsed_s,evidence\n";
    rxReasons << "case_id,sta_id,phy_id,drop_reason_id,mpdu_events\n";
    for (uint32_t i = 0; i < nSta; ++i)
    {
        for (uint8_t l = 0; l < nLinks; ++l)
        {
            const auto& d = probe[i][l];
            const auto& f = stationLink[i][l];
            const bool planned = true;
            std::string evidence = !planned ? "INACTIVE_LINK" :
                (f.rx ? "RX_POSITIVE" :
                 (!PermanentAtSta(i) || !PermanentAtAp(i) ? "ARP_NOT_PERMANENT" :
                  (!d.sendOk ? "NO_APP_SEND" :
                   (!d.macIn ? "NO_MAC_SUBMISSION" :
                    (!d.enq ? "NO_QUEUE_ENQUEUE_OBSERVED" :
                     (!d.acked ? "NO_ACK_OBSERVED" : "ACK_WITHOUT_APP_RX"))))));
            rxDiag << caseId << ",2," << mode << ',' << i << ',' << +l
                << ',' << (l == 0 ? 0 : 3) << ',' << (planned ? offeredLoad / nLinks : 0.0)
                << ',' << DynamicCast<StaWifiMac>(devices[i + 1]->GetMac())->GetSetupLinkIds().size()
                << ',' << PermanentAtSta(i) << ',' << PermanentAtAp(i)
                << ',' << d.sendCalls << ',' << d.sendOk
                << ',' << d.macIn << ',' << d.macReject
                << ',' << d.enq << ',' << d.deq << ',' << d.before
                << ',' << d.after << ',' << d.expired
                << ',' << d.acked << ',' << d.nacked << ',' << d.dropped
                << ',' << f.tx << ',' << f.rx << ',' << d.appRx
                << ',' << (d.firstRx < 0 ? "NA" : Number(d.firstRx))
                << ',' << evidence << '\n';
            for (const auto& item : d.reasons)
                rxReasons << caseId << ',' << i << ',' << +l
                    << ',' << item.first << ',' << item.second << '\n';
        }
    }

    const bool pass = reasons.empty();

    perSta << "case_id,demo,mode,n_sta,sta_id,offered_per_sta_mbps,"
        "tx_packets,rx_packets,rx_bytes,throughput_mbps,delay_ms,jitter_ms,loss_pct,"
        "throughput_5g_mbps,throughput_6g_mbps,setup_links,x_m,y_m,z_m\n";
    for (uint32_t i = 0; i < nSta; ++i)
    {
        auto staMac = DynamicCast<StaWifiMac>(devices[i + 1]->GetMac());
        const auto position = stas.Get(i)->GetObject<MobilityModel>()->GetPosition();
        perSta << caseId << ",2," << mode << ',' << nSta << ',' << i << ',' << offeredLoad << ',';
        WriteKpi(perSta, stationTotal[i]);
        perSta << ',' << Number(Throughput(stationLink[i][mode == "slo6" ? 1 : 0]))
               << ',' << Number(Throughput(stationLink[i][mode == "slo6" ? 0 : 1]))
               << ',' << staMac->GetSetupLinkIds().size()
               << ',' << position.x << ',' << position.y << ',' << position.z << '\n';
    }
    perLink << "case_id,demo,mode,phy_id,mac_link_id,band_ghz,width_mhz,"
        "offered_total_link_mbps,tx_packets,rx_packets,rx_bytes,throughput_mbps,"
        "delay_ms,jitter_ms,loss_pct\n";
    for (uint8_t link = 0; link < nLinks; ++link)
    {
        const auto macLink = devices[0]->GetMac()->GetLinkForPhy(link);
        perLink << caseId << ",2," << mode << ',' << +link << ','
                << (macLink ? std::to_string(*macLink) : "NA") << ',' << (mode == "slo6" || link == 1 ? 6 : 5)
                << ',' << checkWidth << ',' << nSta * offeredLoad / nLinks << ',';
        WriteKpi(perLink, linkTotal[link]);
        perLink << '\n';
    }

    DoubleValue txPower, noiseFigure;
    UintegerValue nss;
    TimeValue queueDelay;
    auto radio = devices[0]->GetPhy(0);
    radio->GetAttribute("TxPowerStart", txPower);
    noiseFigure.Set(7.0);
    radio->GetAttribute("MaxSupportedTxSpatialStreams", nss);
    auto queue = devices[1]->GetMac()->GetQosTxop(AC_BE)->GetWifiMacQueue();
    queueDelay.Set(queue->GetMaxDelay());
    const auto gi = devices[0]->GetHeConfiguration()->GetGuardInterval();

    summary << "schema,case_id,demo,mode,n_sta,offered_per_sta_mbps,offered_total_mbps,"
        "mcs,coding,nss,width5_mhz,width6_mhz,gi_ns,payload_bytes,seed,rng_run,"
        "app_start_s,sim_stop_s,measure_s,radius_m,pathloss,link_policy,tx_power_dbm,"
        "rx_noise_figure_db,queue_max_size,queue_max_delay_ms,tx_packets,rx_packets,"
        "rx_bytes,throughput_mbps,delay_ms,jitter_ms,loss_pct,throughput_5g_mbps,"
        "throughput_6g_mbps,jain_sta,status,reason\n";
    summary << "2," << caseId << ",2," << mode << ',' << nSta << ',' << offeredLoad
            << ',' << nSta * offeredLoad << ",9,BCC," << nss.Get() << ',' << (mode == "slo6" ? 0 : checkWidth) << ','
            << (mode == "slo6" || nLinks == 2 ? checkWidth : 0) << ',' << gi.GetNanoSeconds() << ',' << PAYLOAD
            << ',' << seed << ',' << rngRun << ',' << APP_START << ',' << SIM_STOP
            << ',' << ACTIVE_TIME << ',' << RADIUS << (checkFading ? ",LogDistance+Nakagami," : ",LogDistance,")
            << (nLinks == 2 ? "EVEN_TID0_3_AC_BE" : "SINGLE_LINK")
            << ',' << txPower.Get() << ',' << noiseFigure.Get() << ',' << queue->GetMaxSize()
            << ',' << queueDelay.Get().GetSeconds() * 1000.0 << ',';
    WriteKpi(summary, total);
    summary << ',' << Number(Throughput(linkTotal[mode == "slo6" ? 1 : 0]))
            << ',' << Number(Throughput(linkTotal[mode == "slo6" ? 0 : 1])) << ',' << jain
            << ',' << (pass ? "PASS" : "FAIL") << ',' << JoinReasons(reasons) << '\n';
    summary.flush();
    perSta.flush();
    perLink.flush();
    rxDiag.flush(); rxTimeline.flush(); rxReasons.flush(); rxState.flush(); phyAudit.flush(); mechanismAudit.flush(); mobilityAudit.flush();
    const bool ioOk = summary && perSta && perLink && rxDiag && rxTimeline && rxReasons && rxState && phyAudit && mechanismAudit && mobilityAudit;
    std::cout << "RESULT," << caseId << ',' << (pass && ioOk ? "PASS" : "FAIL")
              << ",throughput_mbps=" << Number(Throughput(total))
              << ",loss_pct=" << Loss(total) << ",reason=" << JoinReasons(reasons) << '\n';
    for (auto& station : sources)
        for (uint8_t link = 0; link < nLinks; ++link) station[link]->Close();
    for (uint8_t link = 0; link < nLinks; ++link) sinks[link]->Close();
    Simulator::Destroy();
    return pass && ioOk ? 0 : 1;
}
